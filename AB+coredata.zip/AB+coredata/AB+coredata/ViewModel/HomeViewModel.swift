//
//  HomeViewModel.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import Foundation
import  Reachability

protocol  HomeViewModelDelegate {
    func didStartFetchingData() ->Void
    func didEndFetchingData() ->Void
}


class HomeViewModel{
    
    //MARK: - Variable Declaration
    var delegate:HomeViewModelDelegate?
    fileprivate let reachability = Reachability()!
    var arrEmployee = Array<Employe>()
    
    init() {}
    
    
    func fetchEmployeeListing(){
        
        let arrEmployee = DBManager.shared.getAllEmployeeData()
        if arrEmployee.count <= 0{
            if reachability.connection != .none{
                delegate?.didStartFetchingData()
                _ = DBManager.shared.clearEmployeeList()
                Service.shared.getEmployeeList { (arrEmployee, error) in
                    self.arrEmployee = arrEmployee ?? Array<Employe>()
                    self.delegate?.didEndFetchingData()
                }
            }
        }else{
            self.getDataFromDataBase(arr: arrEmployee)
        }
    }
    
    
    func getDataFromDataBase(arr: [Employee]){
        delegate?.didStartFetchingData()
        self.arrEmployee = Employe.initToMe(arrEmp: arr)
        self.delegate?.didEndFetchingData()
    }
    
}
