//
//  BaseViewController.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit
import  Reachability

class BaseViewController: UIViewController {

    //MARK: - Variable Declaration
    public let reachability = Reachability()
    
    
    //MARK: - Outlets
    
    //MARK: - View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    //MARK: - Function Declaration
    
    
}
