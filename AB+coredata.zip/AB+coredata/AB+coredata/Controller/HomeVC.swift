//
//  HomeVC.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit

class HomeVC: BaseViewController {

    //MARK: - Variable Declaration
    var viewModel = HomeViewModel()
    
    //MARK: - Outlets
    @IBOutlet weak var tblEmployeeList: UITableView!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    
    //MARK: - View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    

    //MARK: - Function Declaration
    func setupUI(){
        viewModel.delegate = self
        
        viewModel.fetchEmployeeListing()
        tblEmployeeList.register(UINib(nibName: "EmployeeListTVCell", bundle: nil), forCellReuseIdentifier: "EmployeeListTVCell")
        
    }
    
    
}

//MARK: - ViewModel Delegates
extension HomeVC: HomeViewModelDelegate{
    
    func didStartFetchingData() {
        self.indicator.startAnimating()
        self.tblEmployeeList.isHidden = true
    }
    
    func didEndFetchingData() {
        self.indicator.stopAnimating()
        self.tblEmployeeList.isHidden = false
        self.tblEmployeeList.reloadData()
    }
    
    
}

//MARK: - Tableview Datasource
extension HomeVC: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.arrEmployee.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmployeeListTVCell", for: indexPath) as! EmployeeListTVCell
        cell.configCell(viewModel.arrEmployee[indexPath.row])
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let arrEmp = DBManager.shared.deleteEmpData(index: indexPath.row)
        viewModel.getDataFromDataBase(arr: arrEmp)
        self.tblEmployeeList.reloadData()
    }
    

}


