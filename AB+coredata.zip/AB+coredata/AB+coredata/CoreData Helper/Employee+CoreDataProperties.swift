//
//  Employee+CoreDataProperties.swift
//  
//
//  Created by Abhi Makadia on 01/12/19.
//
//

import Foundation
import CoreData


extension Employee {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Employee> {
        return NSFetchRequest<Employee>(entityName: "Employee")
    }

    @NSManaged public var email: String?
    @NSManaged public var first_name: String?
    @NSManaged public var last_name: String?
    @NSManaged public var profileUrls: NSSet?

}

// MARK: Generated accessors for profileUrls
extension Employee {

    @objc(addProfileUrlsObject:)
    @NSManaged public func addToProfileUrls(_ value: ProfilePic)

    @objc(removeProfileUrlsObject:)
    @NSManaged public func removeFromProfileUrls(_ value: ProfilePic)

    @objc(addProfileUrls:)
    @NSManaged public func addToProfileUrls(_ values: NSSet)

    @objc(removeProfileUrls:)
    @NSManaged public func removeFromProfileUrls(_ values: NSSet)

}
