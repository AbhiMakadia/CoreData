//
//  ProfilePic+CoreDataClass.swift
//  
//
//  Created by Abhi Makadia on 01/12/19.
//
//

import Foundation
import CoreData

@objc(ProfilePic)
public class ProfilePic: NSManagedObject {

}
