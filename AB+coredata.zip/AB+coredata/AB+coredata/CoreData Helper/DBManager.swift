//
//  DBManager.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit
import CoreData

class DBManager: NSObject {

    static let shared = DBManager()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func clearEmployeeList() -> Bool{
        
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
            return true
        } catch {
            print ("There was an error")
            return false
        }
        
    }
    
    func deleteEmpData(index: Int) -> [Employee]{
        var employeeData = self.getAllEmployeeData() // GetData
        context.delete(employeeData[index]) // Remove From Coredata
        employeeData.remove(at: index) // Remove in array college
        do{
            try context.save()
        }catch let err{
            print("delete Employe data :- \(err.localizedDescription)")
        }
        return employeeData
    }
    
    func getAllEmployeeData() -> [Employee]{
        var arrEmployee = [Employee]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Employee")
        do{
            arrEmployee = try context.fetch(fetchRequest) as! [Employee]
        }catch let err{
            print("Error in college fetch :- \(err.localizedDescription)")
        }
        return arrEmployee
    }
    
    func addEmployee(obj:Employe) -> Employee?{
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context) as! Employee
        entity.first_name = obj.firstName
        entity.last_name = obj.lastName
        entity.email = obj.email
        
        do{
            try context.save()
            return entity
        }catch let err{
            print("Employe save error :- \(err.localizedDescription)")
            return nil
        }
        
    }
    
    func addImageUrl(url:String,employee:Employee){
        let context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.insertNewObject(forEntityName: "ProfilePic", into: context) as! ProfilePic
        entity.url = url
        entity.person = employee
        do{
            try context.save()
        }catch let err{
            print("Employe save error :- \(err.localizedDescription)")
        }
    }
    
    
}

