//
//  Employee+CoreDataClass.swift
//  
//
//  Created by Abhi Makadia on 01/12/19.
//
//

import Foundation
import CoreData

public class Employee: NSManagedObject {
    
    init(_ dictData:Dictionary<String,Any>) {
        self.first_name = dictData["first_name"] as? String ?? ""
        self.last_name = dictData["last_name"] as? String ?? ""
        self.email = dictData["email"] as? String ?? ""
    }
    
    class func fetchReq() -> NSFetchRequest<NSFetchRequestResult>{
        return Employee.fetchRequest()
    }
    
}
