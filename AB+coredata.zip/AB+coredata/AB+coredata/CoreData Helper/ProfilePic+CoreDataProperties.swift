//
//  ProfilePic+CoreDataProperties.swift
//  
//
//  Created by Abhi Makadia on 01/12/19.
//
//

import Foundation
import CoreData


extension ProfilePic {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ProfilePic> {
        return NSFetchRequest<ProfilePic>(entityName: "ProfilePic")
    }

    @NSManaged public var url: String?
    @NSManaged public var person: Employee?

}
