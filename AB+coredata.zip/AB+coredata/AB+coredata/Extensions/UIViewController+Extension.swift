//
//  UIViewController+Extension.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit

extension UIViewController{
    
    enum AppStoryboard: String {
        case main = "Main"
    }
    
    class func instantiate<T: UIViewController>(appStoryboard: AppStoryboard) -> T {
        
        let storyboard = UIStoryboard(name: appStoryboard.rawValue, bundle: nil)
        let identifier = String(describing: self)
        return storyboard.instantiateViewController(withIdentifier: identifier) as! T
    }
}

extension UIImageView{
    
    func makeRound(){
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
    }
}
