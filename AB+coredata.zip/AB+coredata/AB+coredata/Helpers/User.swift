//
//  User.swift
//  TakeOrToss
//
//  Created by Tristate Technology on 18/07/17.
//  Copyright © 2017 Tristate Technology. All rights reserved.
//

import UIKit

enum UserInfoKey:String {

    //case user_id = "user_id"
    case nick_name = "nick_name"
    case password = "password"
    case unique_key = "unique_key"
    case company_name = "company_name"
    case website_url = "website_url"
    case email_id = "email_id"
    case user_type = "user_type"
    case registered_by = "registered_by"
    case country_code = "country_code"
    case phone_number = "phone_number"
    case profile_pic = "profile_pic"
    case auth_token = "auth_token"
    case refresh_token = "refresh_token"
    case auth_token_bfore_login = "auth_token_bfore_login"
    case tuto_main_flag = "tuto_main"  //1-hidden 2-show
    case tuto_sub_left_rating = "tuto_sub_left_rating"
    case tuto_sub_right_rating = "tuto_sub_right_rating"
    case tuto_sub_profile_rating = "tuto_sub_profile_rating"
    case tuto_sub_this_or_that_second_image = "tuto_sub_this_or_that_second_image"
    case tuto_sub_change_image_name = "tuto_sub_change_image_name"
    case tuto_sub_save_image = "tuto_sub_save_image"
    case tuto_sub_this_or_that_change_img_name = "tuto_sub_this_or_that_change_img_name"
    case tuto_sub_rate_other_take_or_toss_left = "tuto_sub_rate_other_take_or_toss_left"
    case tuto_sub_rate_other_take_or_toss_right = "tuto_sub_rate_other_take_or_toss_right"
    case tuto_sub_rate_other_this_or_that_left = "tuto_sub_rate_other_this_or_that_left"
    case tuto_sub_rate_other_this_or_that_right = "tuto_sub_rate_other_this_or_that_right"
    case tuto_sub_livevoting_this_or_that = "tuto_sub_livevoting_this_or_that"
    case tuto_sub_delete_post = "tuto_sub_delete_post"
    case is_login = "is_login"
}

class User: NSObject {

    //var user_id: String?
    var unique_key: String?
    var password: String?
    var nick_name: String?
    var company_name:String?
    var website_url:String?
    var email_id:String?
    var user_type:String?
    var registered_by: String?
    var country_code:String?
    var phone_number:String?
    var profile_pic:String?
    var auth_token:String?
    var refresh_token:String?
    var auth_token_bfore_login:String?
    var tuto_main_flag:Int?
    var tuto_sub_left_rating:Int?
    var tuto_sub_right_rating:Int?
    var tuto_sub_profile_rating:Int?
    var tuto_sub_this_or_that_second_image:Int?
    var tuto_sub_change_image_name:Int?
    var tuto_sub_save_image:Int?
    var tuto_sub_this_or_that_change_img_name:Int?
    var tuto_sub_rate_other_take_or_toss_left:Int?
    var tuto_sub_rate_other_take_or_toss_right:Int?
    var tuto_sub_rate_other_this_or_that_left:Int?
    var tuto_sub_rate_other_this_or_that_right:Int?
    var tuto_sub_livevoting_this_or_that:Int?
    var tuto_sub_delete_post:Int?
    var is_login:Int?
    
    var allkeys: [UserInfoKey] {
        get {
            return [.unique_key,.password,.nick_name,.company_name,.website_url,.email_id,.user_type,.registered_by, .country_code, .phone_number , .profile_pic, .auth_token, .refresh_token, .auth_token_bfore_login,.tuto_main_flag,.tuto_sub_left_rating,.tuto_sub_right_rating,.tuto_sub_profile_rating,.tuto_sub_this_or_that_second_image,.tuto_sub_change_image_name,.is_login,.tuto_sub_save_image,.tuto_sub_this_or_that_change_img_name,.tuto_sub_rate_other_take_or_toss_left,.tuto_sub_rate_other_take_or_toss_right,.tuto_sub_rate_other_this_or_that_left,.tuto_sub_rate_other_this_or_that_right,.tuto_sub_livevoting_this_or_that,.tuto_sub_delete_post]
        }
    }
    static var currentUser: User = User()
    
    override init() {
        super.init()
        
        let userDefault = UserDefaults.standard
       // self.user_id = userDefault.value(forKey: UserInfoKey.user_id.rawValue) as! String?
        self.unique_key = userDefault.value(forKey: UserInfoKey.unique_key.rawValue) as! String?
        self.password = userDefault.value(forKey: UserInfoKey.password.rawValue) as! String?
        self.nick_name = userDefault.value(forKey: UserInfoKey.nick_name.rawValue) as! String?
        self.company_name = userDefault.value(forKey: UserInfoKey.company_name.rawValue) as! String?
        self.website_url = userDefault.value(forKey: UserInfoKey.website_url.rawValue) as! String?
        self.email_id = userDefault.value(forKey: UserInfoKey.email_id.rawValue) as! String?
        self.user_type = userDefault.value(forKey: UserInfoKey.user_type.rawValue) as! String?
        self.registered_by = userDefault.value(forKey: UserInfoKey.registered_by.rawValue) as! String?
        self.country_code = userDefault.value(forKey: UserInfoKey.country_code.rawValue) as! String?
        self.phone_number = userDefault.value(forKey: UserInfoKey.phone_number.rawValue) as! String?
        self.profile_pic = userDefault.value(forKey: UserInfoKey.profile_pic.rawValue) as! String?
        self.auth_token = userDefault.value(forKey: UserInfoKey.auth_token.rawValue) as! String?
        self.refresh_token = userDefault.value(forKey: UserInfoKey.refresh_token.rawValue) as! String?
        self.auth_token_bfore_login = userDefault.value(forKey: UserInfoKey.auth_token_bfore_login.rawValue) as! String?
        self.is_login = userDefault.value(forKey: UserInfoKey.is_login.rawValue) as! Int?
        self.tuto_main_flag = userDefault.value(forKey: UserInfoKey.tuto_main_flag.rawValue) as! Int?
        self.tuto_sub_left_rating = userDefault.value(forKey: UserInfoKey.tuto_sub_left_rating.rawValue) as! Int?
        self.tuto_sub_right_rating = userDefault.value(forKey: UserInfoKey.tuto_sub_right_rating.rawValue) as! Int?
        self.tuto_sub_profile_rating = userDefault.value(forKey: UserInfoKey.tuto_sub_profile_rating.rawValue) as! Int?
        self.tuto_sub_this_or_that_second_image = userDefault.value(forKey: UserInfoKey.tuto_sub_this_or_that_second_image.rawValue) as! Int?
        self.tuto_sub_change_image_name = userDefault.value(forKey: UserInfoKey.tuto_sub_change_image_name.rawValue) as! Int?
        self.tuto_sub_save_image = userDefault.value(forKey: UserInfoKey.tuto_sub_save_image.rawValue) as! Int?
        self.tuto_sub_this_or_that_change_img_name = userDefault.value(forKey: UserInfoKey.tuto_sub_this_or_that_change_img_name.rawValue) as! Int?
        self.tuto_sub_rate_other_take_or_toss_left = userDefault.value(forKey: UserInfoKey.tuto_sub_rate_other_take_or_toss_left.rawValue) as! Int?
        self.tuto_sub_rate_other_take_or_toss_right = userDefault.value(forKey: UserInfoKey.tuto_sub_rate_other_take_or_toss_right.rawValue) as! Int?
        self.tuto_sub_rate_other_this_or_that_left = userDefault.value(forKey: UserInfoKey.tuto_sub_rate_other_this_or_that_left.rawValue) as! Int?
         self.tuto_sub_rate_other_this_or_that_right = userDefault.value(forKey: UserInfoKey.tuto_sub_rate_other_this_or_that_right.rawValue) as! Int?
        self.tuto_sub_livevoting_this_or_that = userDefault.value(forKey: UserInfoKey.tuto_sub_livevoting_this_or_that.rawValue) as! Int?
        self.tuto_sub_delete_post = userDefault.value(forKey: UserInfoKey.tuto_sub_delete_post.rawValue) as! Int?
        
        
    }
    
    public func saveUserInfo(_ userInfo: Dictionary<String,Any>) {
        var userInfo = userInfo
        let userDefault = UserDefaults.standard
        let keys = Array(userInfo.keys)
        for key in keys {
            if let userKey = UserInfoKey(rawValue: key) {
                
                if userInfo[key] is Int{
                    userInfo[key] = String(userInfo[key] as! Int)
                }
                
                userDefault.set(userInfo[key] as! String, forKey: userKey.rawValue)
                switch userKey {
               /* case .user_id:
                    self.user_id = userInfo[key] as! String?
                    break*/
                case .unique_key:
                    self.unique_key = userInfo[key] as! String?
                    break
                case .password:
                    self.password = userInfo[key] as! String?
                    break
                case .nick_name:
                    self.nick_name = userInfo[key] as! String?
                    break
                case .company_name:
                    self.company_name = userInfo[key] as! String?
                    break
                case .website_url:
                    self.website_url = userInfo[key] as! String?
                    break
                case .email_id:
                    self.email_id = userInfo[key] as! String?
                    break
                case .user_type:
                    self.user_type = userInfo[key] as! String?
                    break
                case .registered_by:
                    self.registered_by = userInfo[key] as! String?
                    break
                case .country_code:
                    self.country_code = userInfo[key] as! String?
                    break
                case .phone_number:
                    self.phone_number = userInfo[key] as! String?
                    break
                case .profile_pic:
                    self.profile_pic = userInfo[key] as! String?
                    break
                case .auth_token:
                    self.auth_token = userInfo[key] as! String?
                    break
                case .refresh_token:
                    self.refresh_token = userInfo[key] as! String?
                    break
                default:
                    break
                }
            }
        
        }
        userDefault.synchronize()
        User.currentUser = User()
        
    }
    
    public func saveRefreshToken(_ dictToken: Dictionary<String,Any>){
        
       let userDefault = UserDefaults.standard
       userDefault.set(dictToken["auth_token"] as! String, forKey: UserInfoKey.auth_token_bfore_login.rawValue)
       self.auth_token_bfore_login = dictToken["auth_token"] as! String?
       userDefault.synchronize()
       User.currentUser = User()
    }
    
    public func isLogin(_ flag:Int){
        let userDefault = UserDefaults.standard
        userDefault.set(flag, forKey: UserInfoKey.is_login.rawValue)
        self.is_login = flag
        userDefault.synchronize()
        User.currentUser = User()
    }
    
    
   public func removeUserData() {
        let defaults = UserDefaults.standard
        let dictionary = defaults.dictionaryRepresentation()
        dictionary.keys.forEach { key in
            defaults.removeObject(forKey: key)
        }
        defaults.synchronize()
        User.currentUser = User()
    }
    
    public func saveTutoMainFlag(_ flag: Int) {
        let userDefault = UserDefaults.standard
        userDefault.set(flag, forKey: UserInfoKey.tuto_main_flag.rawValue)
        self.tuto_main_flag = flag
        userDefault.synchronize()
        User.currentUser = User()
    }
    
    public func saveSubTutoFlag(key: String,value:Int){
        let userDefault = UserDefaults.standard
        userDefault.set(value, forKey: key)
        //"\(key)" = value
        userDefault.synchronize()
        User.currentUser = User()
    }
    
    
}

////MARK: - Variable Declaration
//var txtYposition:CGFloat = 0.0
//
////MARK: - Function Declaration
//func keyboardWillShow(notification: NSNotification) {
//    self.scrollView.isScrollEnabled = true
//    let info : NSDictionary = notification.userInfo! as NSDictionary
//    let keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
//    let contentInsets : UIEdgeInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: keyboardSize!.height, right: 0.0)
//    self.scrollView.contentInset = contentInsets
//    self.scrollView.scrollIndicatorInsets = contentInsets
//    let myView = UIView(frame: CGRect(x: 0, y: self.txtYposition  , width: 280, height: 30))
//    self.scrollView.scrollRectToVisible(myView.frame, animated: true)
//}
//
//func keyboardWillHide(notification: NSNotification) {
//    let contentInsets: UIEdgeInsets = UIEdgeInsets.zero
//    self.scrollView.contentInset = contentInsets
//    self.scrollView.scrollIndicatorInsets = contentInsets
//}
//
////MARK: - TextField Delegate
//extension LoginViewController : UITextFieldDelegate{
//
//    func textFieldShouldReturn(_ textField: UITextField) -> Bool
//    {
//        textField.resignFirstResponder()
//        return true;
//    }
//
//    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
//        self.txtYposition = CGFloat(textField.frame.origin.y) + CGFloat(textField.frame.size.height)
//        return true
//    }
//
//}
