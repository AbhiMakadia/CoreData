

//
//  Constants.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit

struct Constant {
    static let employeeUrl = "https://reqres.in/api/users?page=1"
}
