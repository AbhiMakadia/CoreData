//
//  Service.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit
import  Alamofire

class Service: NSObject {

    static let shared = Service()
    
    func getEmployeeList(completionHandler: @escaping (_ result: Array<Employe>?,_ error:Error?) -> Void){
        
        Alamofire.request(Constant.employeeUrl)
            .responseJSON { response in
                
                guard response.result.isSuccess else{
                    completionHandler(nil,response.result.error!)
                    return
                }
                
                guard let json = response.result.value as? Dictionary<String,Any> else{
                    print("DOnt get todo object as JSON from API")
                    print("Error: \(String(describing: response.result.error))")
                    completionHandler(nil,nil)
                    return
                }
                //completionHandler(json,nil)
                if let arrEmployee = json["data"] as? Array<Dictionary<String,Any>>{
                    completionHandler(arrEmployee.map({(element: Dictionary<String,Any>) -> Employe in
                        
                        let objEmp = Employe(element)
                        let objPerson = DBManager.shared.addEmployee(obj: objEmp)
                        DBManager.shared.addImageUrl(url: element["avatar"] as? String ?? "", employee: objPerson!)
                        return objEmp
                        
                    }), nil)
                }else{
                    completionHandler(nil,nil)
                }
                
                
        }
        
        
        
    }
    
    
}

