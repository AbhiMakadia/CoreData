//
//  EmployeeListTVCell.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit

class EmployeeListTVCell: UITableViewCell {

    
    //MARK: - Variable Declaration
    
    //MARK: - Outlets
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var imgProfile: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgProfile.makeRound()
    }

    
    func configCell(_ obj: Employe){
        lblUserName.text = obj.firstName + " " + obj.lastName
        print(obj.email)
        print(obj.avatar)
    }
    
    
}
