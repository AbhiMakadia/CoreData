//
//  Employee.swift
//  AB+coredata
//
//  Created by Abhi Makadia on 01/12/19.
//  Copyright © 2019 Abhi Makadia. All rights reserved.
//

import UIKit

class Employe: NSObject {

    var firstName:String = ""
    var lastName:String = ""
    var email:String = ""
    var avatar:String = ""
    
    override init() {
        super.init()
    }
    
    init(_ dictData:Dictionary<String,Any>) {
        self.firstName = dictData["first_name"] as? String ?? ""
        self.lastName = dictData["last_name"] as? String ?? ""
        self.email = dictData["email"] as? String ?? ""
        self.avatar = dictData["avatar"] as? String ?? ""
    }
    
    class func initToMe(arrEmp:Array<Employee>) -> Array<Employe>{
        
        return arrEmp.map({(element: Employee) -> Employe in
            
            let obj = Employe()
            obj.firstName = element.first_name ?? ""
            obj.lastName = element.last_name ?? ""
            obj.email = element.email ?? ""
            
            if let profilePic = element.profileUrls?.allObjects.first as? ProfilePic{
                obj.avatar = profilePic.url ?? ""
            }
            
            return obj
        })
    }
    
    
}
